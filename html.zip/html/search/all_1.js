var searchData=
[
  ['birthday',['birthday',['../class_people.html#a5be721184ae0e81eaafa682cfa33445c',1,'People']]]
];
