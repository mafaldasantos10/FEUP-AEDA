var searchData=
[
  ['uc',['Uc',['../class_uc.html',1,'Uc'],['../class_uc.html#ad5da57e7b1cb68830de9a9aa47e7efe4',1,'Uc::Uc(string name, vector&lt; Teacher *&gt; teacher, vector&lt; Student *&gt; student, int year, int ects, int workload)'],['../class_uc.html#a5f40c9448de2b94997b852e8a3769475',1,'Uc::Uc(string name, int year, int ects, int workload)']]],
  ['ucects',['ucECTS',['../class_uc.html#a17c903339f45845c300885d93ebb9cf2',1,'Uc']]],
  ['ucname',['ucName',['../class_uc.html#ad66a93e522661d5b423177bd4204ae97',1,'Uc']]],
  ['ucstudent',['ucStudent',['../class_uc.html#a419680d6225d7b872382318136a2e2cf',1,'Uc']]],
  ['ucteacher',['ucTeacher',['../class_uc.html#aebef02ec904dbba15514a3e939663ed4',1,'Uc']]],
  ['ucworkload',['ucWorkload',['../class_uc.html#a33d749f5e126e59a731c33b440cf4d21',1,'Uc']]],
  ['ucyear',['ucYear',['../class_uc.html#a46ebf0756460b0d02bd6f13df902497f',1,'Uc']]],
  ['user_5fid',['user_id',['../main_8cpp.html#a28cda6532ca41bacbadb57a0a18df214',1,'main.cpp']]]
];
