var searchData=
[
  ['teacher',['Teacher',['../class_teacher.html',1,'Teacher'],['../class_teacher.html#a4ec298203de7bc9e402605455a6d9783',1,'Teacher::Teacher(string name, string address, date birthday, unsigned int phone, string cod, float salary, unsigned int nif, bool working, Cat category, vector&lt; Uc *&gt; subjects)'],['../class_teacher.html#a0cb61f83bfd46b864a9ad4bc43e4c8fa',1,'Teacher::Teacher()=default']]],
  ['teacher_5fcount',['teacher_count',['../class_teacher.html#a571806aabeb146493580e04e35fb7d10',1,'Teacher']]],
  ['teacher_5ftable',['teacher_table',['../class_employee_ptr.html#ad9f56246db5fb6c6db6f428192c39ed5',1,'EmployeePtr']]],
  ['teachers',['teachers',['../class_college.html#af0c7dc5ec057ce87c19ed29bc0de6dbd',1,'College']]],
  ['type',['type',['../class_employee_ptr.html#ab066c48487ef3e30f51bce129a864cb4',1,'EmployeePtr']]]
];
