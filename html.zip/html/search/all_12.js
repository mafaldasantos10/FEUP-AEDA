var searchData=
[
  ['work_5farea',['work_area',['../class_staff.html#a6b24a8a4dfd403ef6992cc8e4d136b48',1,'Staff']]]
];
