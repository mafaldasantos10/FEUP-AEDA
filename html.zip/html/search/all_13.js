var searchData=
[
  ['year',['year',['../structdate.html#ac4d486cd54c0d08bef8edb2fb4c610cc',1,'date']]]
];
