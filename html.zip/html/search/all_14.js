var searchData=
[
  ['_7epeople',['~People',['../class_people.html#adae124857f64dadff4e1801410b3dab2',1,'People']]]
];
