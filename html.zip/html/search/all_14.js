var searchData=
[
  ['year',['year',['../structdate.html#ac4d486cd54c0d08bef8edb2fb4c610cc',1,'date::year()'],['../class_student.html#aca42f18eeeadf5428cf30a3078a97389',1,'Student::year()']]]
];
