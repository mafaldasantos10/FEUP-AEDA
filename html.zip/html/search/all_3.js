var searchData=
[
  ['date',['date',['../structdate.html',1,'date'],['../structdate.html#a6a1b27208f78056398546c586544d896',1,'date::date()']]],
  ['day',['day',['../structdate.html#ab66964bfc48e3ebe732db1cb305d24ef',1,'date']]],
  ['default',['Default',['../_people_8h.html#adde5bc885e2b38acffbe0be3d39857e9a79935518a3889663d8688b6b01fff051',1,'People.h']]],
  ['deleteteachers',['deleteTeachers',['../class_college.html#a69be8882526cbe299c68ebab9531cb5a',1,'College']]],
  ['dep_5fmenu',['Dep_Menu',['../main_8cpp.html#a25d9e048f1dd33fefa2b6d754d04218e',1,'main.cpp']]],
  ['depaddress',['depAddress',['../class_department.html#ae9781c5f60134d6384fb985650d41848',1,'Department']]],
  ['department',['Department',['../class_department.html',1,'Department'],['../class_department.html#a9c2a5e16b1102cd799f26d311b663ae4',1,'Department::Department(string name, int code, string address, int phone, Teacher *director)'],['../class_department.html#ad82d8a3117139e58155b265586a539b5',1,'Department::Department(string name, int code, string address, int phone)'],['../class_department.html#aedbe097ef531ba1f26aa640d6acb3b9b',1,'Department::Department()=default']]],
  ['departments_5fmenu',['Departments_Menu',['../main_8cpp.html#ac3f1b2d74ff0f48d090215062cb26b61',1,'main.cpp']]],
  ['depcode',['depCode',['../class_department.html#af6846ad24d9e752e5b18f970de0f5464',1,'Department']]],
  ['depdir',['DepDir',['../_people_8h.html#adde5bc885e2b38acffbe0be3d39857e9ad768bb543228952ffbfcc23f8e932ffa',1,'People.h']]],
  ['depdirector',['depDirector',['../class_department.html#a11288ea80f3bc0699539abffb6ce53da',1,'Department']]],
  ['depname',['depName',['../class_department.html#a79ddd17e959ee7d2e4f3c17c160c625e',1,'Department']]],
  ['depphone',['depPhone',['../class_department.html#a544bb205f31c7eb17655810e9fbaeb5f',1,'Department']]],
  ['dest_5fremove',['dest_remove',['../_college_8h.html#a9bd5591b2cb0708be1dd59c65c062c66',1,'College.h']]]
];
