var searchData=
[
  ['insertaddress',['InsertAddress',['../class_people.html#a0fc4387b4486e8c205107d24866446d8',1,'People']]],
  ['insertbirthday',['InsertBirthday',['../class_people.html#af46f7c0c1cfb29b2f208c831a8f63f29',1,'People']]],
  ['insertname',['InsertName',['../class_people.html#afd0ed93ae3d6bdba5bbd02eb3a3895b1',1,'People']]],
  ['insertnif',['InsertNif',['../class_employee.html#a1b2a0810a5b4e4246aa668d9cda431a6',1,'Employee']]],
  ['insertphone',['InsertPhone',['../class_people.html#a770f0983cf4d27db5236e745fc8fd05d',1,'People']]],
  ['insertsalary',['InsertSalary',['../class_employee.html#a5c5ecef4514d5ecf23f337c5b669f3a1',1,'Employee']]],
  ['insertteacheruc',['InsertTeacherUc',['../class_teacher.html#a68a28f69b22cbd11f060b5234d1f0f46',1,'Teacher']]],
  ['insertuc',['InsertUC',['../class_student.html#a68f8e3b6aa6c23b9c4d405db33a4aa25',1,'Student']]],
  ['insertworkarea',['InsertWorkArea',['../class_staff.html#aae5fe9f5b4846038906b48c67d950709',1,'Staff']]],
  ['insertyear',['InsertYear',['../class_student.html#ac2b2cd970e57382bb9b5c3422ef3d916',1,'Student']]]
];
