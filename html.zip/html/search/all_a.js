var searchData=
[
  ['name',['name',['../class_no_name_found.html#afb09936c78db8a9b3c99a77ba34619c5',1,'NoNameFound::name()'],['../class_people.html#a4763c9a6979b890bf8a8cf9c4cf252aa',1,'People::name()']]],
  ['nav',['Nav',['../_college_8h.html#a2b971d2bc86e4acb9bbe523cff12bdca',1,'Nav(int bottom, int top):&#160;main.cpp'],['../main_8cpp.html#a2b971d2bc86e4acb9bbe523cff12bdca',1,'Nav(int bottom, int top):&#160;main.cpp'],['../_people_8h.html#a2b971d2bc86e4acb9bbe523cff12bdca',1,'Nav(int bottom, int top):&#160;main.cpp']]],
  ['new_5fcollege',['New_College',['../main_8cpp.html#adcede180d095490d20e2ee77b1363caf',1,'main.cpp']]],
  ['nif',['nif',['../class_employee.html#a983b395c4f554ea56b66838de3eef0a2',1,'Employee']]],
  ['nocodefound',['NoCodeFound',['../class_no_code_found.html',1,'NoCodeFound'],['../class_no_code_found.html#a6d60a0b3a2a337080b19a8037dad7c2c',1,'NoCodeFound::NoCodeFound()']]],
  ['nonamefound',['NoNameFound',['../class_no_name_found.html',1,'NoNameFound'],['../class_no_name_found.html#a9065d12c986d917097c35f9e6d8554b0',1,'NoNameFound::NoNameFound()']]]
];
