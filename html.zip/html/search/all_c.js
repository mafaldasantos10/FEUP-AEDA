var searchData=
[
  ['people',['People',['../class_people.html',1,'People'],['../class_college.html#a3f82b5a9c384ed89394f52b4e6d4865c',1,'College::people()'],['../class_people.html#a929c6be5bbb5631160450350eea2c21c',1,'People::People()']]],
  ['people_2ecpp',['People.cpp',['../_people_8cpp.html',1,'']]],
  ['people_2eh',['People.h',['../_people_8h.html',1,'']]],
  ['people_5fmenu',['People_Menu',['../main_8cpp.html#afdfb510729e04983becae450b0ad5265',1,'main.cpp']]],
  ['person_5fmenu',['Person_Menu',['../main_8cpp.html#a5281d3cbf14481474c2e274c519d8383',1,'main.cpp']]],
  ['phone',['phone',['../class_people.html#a8c9e2535a3aa3bf236c75372ce2fd4c4',1,'People']]],
  ['print_5fvec',['Print_Vec',['../_college_8h.html#aa5bee00c080ebebc4d8a87383e7d354a',1,'College.h']]]
];
