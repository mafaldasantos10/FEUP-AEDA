var searchData=
[
  ['readdate',['readDate',['../_college_8h.html#a29527caffc790b120fa090183b035751',1,'readDate():&#160;main.cpp'],['../main_8cpp.html#a29527caffc790b120fa090183b035751',1,'readDate():&#160;main.cpp']]],
  ['remove',['remove',['../_college_8h.html#a37c75b06af266ef396cafa4d35a60ab1',1,'College.h']]],
  ['removecourse',['removeCourse',['../class_college.html#ac946d2004a0edac5dd9a1ac718266db6',1,'College::removeCourse()'],['../class_department.html#aa1a3a326c6c8fba38c916b4bf9581d98',1,'Department::removeCourse()']]],
  ['removedepartment',['removeDepartment',['../class_college.html#a1a69c3c5f81f6d791aa8196db0acf652',1,'College']]],
  ['removefrommap',['removeFromMap',['../class_student.html#ac8903d5198bb4042b8f375f3c29b3ce6',1,'Student']]],
  ['removestudent',['removeStudent',['../class_uc.html#a0a017e6b84c0352d2f319e6a8508dcd2',1,'Uc']]],
  ['removeteacher',['removeTeacher',['../class_uc.html#a8271492c8ccfcc6d3301b823bf9c5e04',1,'Uc']]],
  ['removeuc',['removeUC',['../class_course.html#a179fc6ab41cbe397b90221ac7ae2bfa6',1,'Course']]]
];
