var searchData=
[
  ['readdate',['readDate',['../_college_8h.html#a29527caffc790b120fa090183b035751',1,'readDate():&#160;main.cpp'],['../main_8cpp.html#a29527caffc790b120fa090183b035751',1,'readDate():&#160;main.cpp']]],
  ['readfile',['readFile',['../main_8cpp.html#a1009945b0d931137873d45838f350e6b',1,'main.cpp']]],
  ['reg',['Reg',['../_people_8h.html#adde5bc885e2b38acffbe0be3d39857e9afbf76e0af5b4d515f085475470a905d1',1,'People.h']]],
  ['regent',['Regent',['../class_uc.html#a00d27a8c23ab3dec6deac8255787be64',1,'Uc']]],
  ['remove',['remove',['../_college_8h.html#aeafdb389b8c21f7626a4de564aeea110',1,'College.h']]],
  ['remove_5fperson',['Remove_Person',['../main_8cpp.html#a34fdceab4dd03085bc7f95f95f6ee8f0',1,'main.cpp']]],
  ['removecourse',['removeCourse',['../class_college.html#ac946d2004a0edac5dd9a1ac718266db6',1,'College::removeCourse()'],['../class_department.html#aa1a3a326c6c8fba38c916b4bf9581d98',1,'Department::removeCourse()']]],
  ['removedepartment',['removeDepartment',['../class_college.html#a1a69c3c5f81f6d791aa8196db0acf652',1,'College']]],
  ['removefrommap',['removeFromMap',['../class_student.html#ab98a56353ccdf663b7c936f811504836',1,'Student']]],
  ['removestaff',['removeStaff',['../class_college.html#a8f6e55cdb4fbbd814d896b8548fde1cc',1,'College']]],
  ['removestudent',['removeStudent',['../class_college.html#a1d59265b6fabac6a9aca8b191c486e36',1,'College::removeStudent()'],['../class_uc.html#a0a017e6b84c0352d2f319e6a8508dcd2',1,'Uc::removeStudent()']]],
  ['removeteacher',['removeTeacher',['../class_college.html#a7abd6bb18c8aec73978fa52273ebe51b',1,'College::removeTeacher()'],['../class_uc.html#a8271492c8ccfcc6d3301b823bf9c5e04',1,'Uc::removeTeacher()']]],
  ['removeteacheruc',['RemoveTeacherUc',['../class_teacher.html#a6bbc3643e4df11e0247d28d5140db19c',1,'Teacher']]],
  ['removeuc',['removeUC',['../class_course.html#a179fc6ab41cbe397b90221ac7ae2bfa6',1,'Course']]]
];
