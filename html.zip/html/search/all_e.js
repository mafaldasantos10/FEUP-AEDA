var searchData=
[
  ['queue_5fcompare',['Queue_Compare',['../class_student.html#a3a7f32601f5a058aebfb621787968710',1,'Student']]],
  ['queue_5fmenu',['Queue_Menu',['../main_8cpp.html#ae88cadec4294f779fe83e0da98f0754a',1,'main.cpp']]]
];
