var searchData=
[
  ['college',['College',['../class_college.html',1,'']]],
  ['course',['Course',['../class_course.html',1,'']]]
];
