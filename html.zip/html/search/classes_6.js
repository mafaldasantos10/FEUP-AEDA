var searchData=
[
  ['staff',['Staff',['../class_staff.html',1,'']]],
  ['student',['Student',['../class_student.html',1,'']]],
  ['student_5fptr',['Student_Ptr',['../class_student___ptr.html',1,'']]]
];
