var searchData=
[
  ['aux',['Aux',['../_people_8h.html#adde5bc885e2b38acffbe0be3d39857e9a2869aba1ca8e23785d36587dd10247d0',1,'People.h']]]
];
