var searchData=
[
  ['coursedir',['CourseDir',['../_people_8h.html#adde5bc885e2b38acffbe0be3d39857e9a36af7bec9778bdd860574f34d0a444f2',1,'People.h']]]
];
