var searchData=
[
  ['default',['Default',['../_people_8h.html#adde5bc885e2b38acffbe0be3d39857e9a79935518a3889663d8688b6b01fff051',1,'People.h']]],
  ['depdir',['DepDir',['../_people_8h.html#adde5bc885e2b38acffbe0be3d39857e9ad768bb543228952ffbfcc23f8e932ffa',1,'People.h']]]
];
