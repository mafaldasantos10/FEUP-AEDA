var searchData=
[
  ['reg',['Reg',['../_people_8h.html#adde5bc885e2b38acffbe0be3d39857e9afbf76e0af5b4d515f085475470a905d1',1,'People.h']]]
];
