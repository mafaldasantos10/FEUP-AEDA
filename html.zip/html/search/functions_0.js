var searchData=
[
  ['add_5fperson',['Add_Person',['../main_8cpp.html#a9df4f32f0953d60a62c8ec6009ff6656',1,'main.cpp']]],
  ['addcourse',['addCourse',['../class_college.html#a3a4d3548e38e856b3a5dadc500791a5b',1,'College::addCourse()'],['../class_department.html#a7713c053d184cd6be33ed194e92dc33a',1,'Department::addCourse()']]],
  ['adddepartment',['addDepartment',['../class_college.html#a11e7448add4862ddf2062c7d2cc11ea5',1,'College']]],
  ['addperson',['addPerson',['../class_people.html#a48993ab7e044192134144e4950582b06',1,'People::addPerson()'],['../class_student.html#a2d4ade19b5c12724e3544d3996989323',1,'Student::addPerson()'],['../class_employee.html#adbd8f5672ecd5995124cc432092695d7',1,'Employee::addPerson()'],['../class_teacher.html#a63eec59741c857910353f15b81acc4c1',1,'Teacher::addPerson()'],['../class_staff.html#a753f8c2342dfed0caaae3009a4ae7daa',1,'Staff::addPerson()']]],
  ['addstaff',['addStaff',['../class_college.html#a119371cb9c16c0b186336a115857bc07',1,'College']]],
  ['addstudent',['addStudent',['../class_college.html#a877137d38f1b2f1769aefec2540c9706',1,'College::addStudent()'],['../class_uc.html#aee6bf098d1e9ce011a0d66f9cdc41d6c',1,'Uc::addStudent()']]],
  ['addsubject',['addSubject',['../class_teacher.html#ad49c3f74e3d37e58040dddb342fccdd0',1,'Teacher']]],
  ['addteacher',['addTeacher',['../class_college.html#a871b8a096f3ca690d0fbf2ac2f23a089',1,'College::addTeacher()'],['../class_uc.html#a302831c79986d8b19b8135182c481df6',1,'Uc::addTeacher()']]],
  ['adduc',['addUC',['../class_course.html#a559973190b0180ea6f1ae0e7911370cb',1,'Course']]],
  ['adducgrade',['addUCGrade',['../class_student.html#a5386ea9fec1e1810bfe33a3c0f50ee6b',1,'Student']]],
  ['admin_5flogin',['Admin_LogIn',['../main_8cpp.html#a45a63703de4f34a75d8d8cdd611e9e22',1,'main.cpp']]],
  ['admin_5fmenu',['Admin_Menu',['../main_8cpp.html#afc85611bac2fcf72bc4a71bf294b5efe',1,'main.cpp']]]
];
