var searchData=
[
  ['addcourse',['addCourse',['../class_college.html#aeaa6312477e791d52bcbb9eb639338e3',1,'College::addCourse()'],['../class_department.html#ac0c35369cda261fcca4d0ce34db3de67',1,'Department::addCourse()']]],
  ['adddepartment',['addDepartment',['../class_college.html#a11e7448add4862ddf2062c7d2cc11ea5',1,'College']]],
  ['addpeople',['addPeople',['../class_college.html#a349c49e7b48b13b8b36b17e279520e39',1,'College']]],
  ['addperson',['addPerson',['../class_college.html#ac9e4bfa52b8406c3f265fed8125a835f',1,'College']]],
  ['addstaff',['addStaff',['../class_college.html#a98c25dc7bebda8c42a759425d88d76ae',1,'College']]],
  ['addstudent',['addStudent',['../class_college.html#a68c30c3ab4f070574cbc5713d6abeb9c',1,'College']]],
  ['addsubject',['addSubject',['../class_teacher.html#ad49c3f74e3d37e58040dddb342fccdd0',1,'Teacher']]],
  ['addteacher',['addTeacher',['../class_college.html#a66d655764be5bba317e3c8bce0400629',1,'College']]],
  ['adduc',['addUC',['../class_course.html#aa4f28c8e4bd29972a518879bbf5097ce',1,'Course']]],
  ['adducgrade',['addUCGrade',['../class_student.html#a86d70c731654963a9881b651755ff02f',1,'Student']]],
  ['admin_5fmenu',['Admin_Menu',['../main_8cpp.html#afc85611bac2fcf72bc4a71bf294b5efe',1,'main.cpp']]]
];
