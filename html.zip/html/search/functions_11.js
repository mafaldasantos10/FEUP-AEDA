var searchData=
[
  ['teacher',['Teacher',['../class_teacher.html#a4ec298203de7bc9e402605455a6d9783',1,'Teacher::Teacher(string name, string address, date birthday, unsigned int phone, string cod, float salary, unsigned int nif, bool working, Cat category, vector&lt; Uc *&gt; subjects)'],['../class_teacher.html#a0cb61f83bfd46b864a9ad4bc43e4c8fa',1,'Teacher::Teacher()=default']]]
];
