var searchData=
[
  ['uc',['Uc',['../class_uc.html#a77f1df55d52be10ec236acab11f3db5e',1,'Uc::Uc(string name, vector&lt; Teacher *&gt; teacher, vector&lt; Student *&gt; student, int year, int ects, int workload, Teacher *director)'],['../class_uc.html#a885febef8d56ceafd9c0bb345313cac9',1,'Uc::Uc(string name, int year, int ects, int workload, Teacher *director)'],['../class_uc.html#a1cc0efddc66f93eb43e1587332d8eabf',1,'Uc::Uc()=default']]],
  ['uc_5fmenu',['Uc_Menu',['../main_8cpp.html#adf1c399e0f097cbff258b41d68d1728a',1,'main.cpp']]],
  ['updatecat',['UpdateCat',['../class_teacher.html#a743f1e19c81c58228f6a8bb6aba2d0c1',1,'Teacher']]]
];
