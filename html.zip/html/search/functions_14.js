var searchData=
[
  ['write',['write',['../class_people.html#ab80f7b32390a0d238bc6b4ea9f1e47a8',1,'People::write()'],['../class_student.html#aad6586d07f3963fd1057bb27e1e5bb56',1,'Student::write()'],['../class_employee.html#a75a36a5175e7d455ab085394ce004310',1,'Employee::write()'],['../class_teacher.html#af4433ce173e9c336efa5cbc433e46a98',1,'Teacher::write()'],['../class_staff.html#aeedec3a9c40d6fb0327c0867b4612ee5',1,'Staff::write()']]]
];
