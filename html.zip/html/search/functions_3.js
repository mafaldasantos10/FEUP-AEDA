var searchData=
[
  ['date',['date',['../structdate.html#a6a1b27208f78056398546c586544d896',1,'date']]],
  ['deleteteachers',['deleteTeachers',['../class_college.html#a69be8882526cbe299c68ebab9531cb5a',1,'College']]],
  ['dep_5fmenu',['Dep_Menu',['../main_8cpp.html#a25d9e048f1dd33fefa2b6d754d04218e',1,'main.cpp']]],
  ['department',['Department',['../class_department.html#a9c2a5e16b1102cd799f26d311b663ae4',1,'Department::Department(string name, int code, string address, int phone, Teacher *director)'],['../class_department.html#ad82d8a3117139e58155b265586a539b5',1,'Department::Department(string name, int code, string address, int phone)'],['../class_department.html#aedbe097ef531ba1f26aa640d6acb3b9b',1,'Department::Department()=default']]],
  ['departments_5fmenu',['Departments_Menu',['../main_8cpp.html#ac3f1b2d74ff0f48d090215062cb26b61',1,'main.cpp']]],
  ['dest_5fremove',['dest_remove',['../_college_8h.html#a9bd5591b2cb0708be1dd59c65c062c66',1,'College.h']]]
];
