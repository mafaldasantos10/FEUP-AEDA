var searchData=
[
  ['people',['People',['../class_people.html#a929c6be5bbb5631160450350eea2c21c',1,'People::People(string name, string address, date &amp;birthday, unsigned int phone, string cod)'],['../class_people.html#ae59abff78030c2b912eb3f664036ae2f',1,'People::People()=default']]],
  ['people_5fmenu',['People_Menu',['../main_8cpp.html#afdfb510729e04983becae450b0ad5265',1,'main.cpp']]],
  ['person_5fmenu',['Person_Menu',['../main_8cpp.html#a7f075b3183f3a3711882c1b0ef7a4d53',1,'main.cpp']]],
  ['print_5fvec',['Print_Vec',['../_college_8h.html#aa5bee00c080ebebc4d8a87383e7d354a',1,'College.h']]]
];
