var searchData=
[
  ['uc',['Uc',['../class_uc.html#ad5da57e7b1cb68830de9a9aa47e7efe4',1,'Uc::Uc(string name, vector&lt; Teacher *&gt; teacher, vector&lt; Student *&gt; student, int year, int ects, int workload)'],['../class_uc.html#a5f40c9448de2b94997b852e8a3769475',1,'Uc::Uc(string name, int year, int ects, int workload)']]]
];
