var searchData=
[
  ['employeeptr',['EmployeePtr',['../class_employee.html#a58179ef982ef131b374987f92a7fe753',1,'Employee::EmployeePtr()'],['../class_teacher.html#a58179ef982ef131b374987f92a7fe753',1,'Teacher::EmployeePtr()'],['../class_staff.html#a58179ef982ef131b374987f92a7fe753',1,'Staff::EmployeePtr()']]]
];
