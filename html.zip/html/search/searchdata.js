var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstuvwy~",
  1: "bcdenpstu",
  2: "bcmp",
  3: "abcdefghilmnopqrstuvw~",
  4: "abcdefilmnprstuvwy",
  5: "h",
  6: "c",
  7: "acdr",
  8: "beo"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends"
};

