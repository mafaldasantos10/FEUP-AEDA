var searchData=
[
  ['access',['access',['../main_8cpp.html#afa2ba4363dd82e4d4f6ad861f94e7f7e',1,'main.cpp']]],
  ['address',['address',['../class_people.html#a821580d9356dc6615ff22714d8a4f000',1,'People']]],
  ['admin',['admin',['../class_college.html#aeaba3eb12a69bd46151322c86b2cf71f',1,'College']]],
  ['atime',['aTime',['../main_8cpp.html#af89874e416175ffeab51b4efcecf6f9c',1,'main.cpp']]]
];
