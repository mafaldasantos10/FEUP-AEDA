var searchData=
[
  ['access',['access',['../main_8cpp.html#afa2ba4363dd82e4d4f6ad861f94e7f7e',1,'access():&#160;main.cpp'],['../_people_8h.html#afa2ba4363dd82e4d4f6ad861f94e7f7e',1,'access():&#160;main.cpp']]],
  ['address',['address',['../class_people.html#a821580d9356dc6615ff22714d8a4f000',1,'People']]],
  ['admin',['admin',['../class_college.html#aeaba3eb12a69bd46151322c86b2cf71f',1,'College']]],
  ['average',['average',['../class_student.html#a978bd177318508ec1d37dec31549ea58',1,'Student']]]
];
