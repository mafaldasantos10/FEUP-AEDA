var searchData=
[
  ['work_5farea',['work_area',['../class_staff.html#a6b24a8a4dfd403ef6992cc8e4d136b48',1,'Staff']]],
  ['working',['working',['../class_employee.html#a5d9e9c6ef9fcb680e3fa1bb19541288d',1,'Employee']]]
];
