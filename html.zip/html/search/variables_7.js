var searchData=
[
  ['name',['name',['../class_no_name_found.html#afb09936c78db8a9b3c99a77ba34619c5',1,'NoNameFound::name()'],['../class_people.html#a4763c9a6979b890bf8a8cf9c4cf252aa',1,'People::name()']]],
  ['nif',['nif',['../class_employee.html#a983b395c4f554ea56b66838de3eef0a2',1,'Employee']]]
];
