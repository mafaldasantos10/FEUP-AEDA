var searchData=
[
  ['phone',['phone',['../class_people.html#a8c9e2535a3aa3bf236c75372ce2fd4c4',1,'People']]]
];
