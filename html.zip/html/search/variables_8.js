var searchData=
[
  ['regent',['Regent',['../class_uc.html#a00d27a8c23ab3dec6deac8255787be64',1,'Uc']]]
];
