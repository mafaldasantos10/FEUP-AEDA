var searchData=
[
  ['people',['people',['../class_college.html#a3f82b5a9c384ed89394f52b4e6d4865c',1,'College']]],
  ['phone',['phone',['../class_people.html#a8c9e2535a3aa3bf236c75372ce2fd4c4',1,'People']]]
];
