var searchData=
[
  ['salary',['salary',['../class_employee.html#a0ad15a19af8e442ceeb212ca9fbc2d50',1,'Employee']]],
  ['staff',['staff',['../class_college.html#a07b018bd8f52f8ea5e835d5aaf993cc9',1,'College']]],
  ['staff_5fcount',['staff_count',['../class_staff.html#a1a2f038a039b1866c757315de15cceba',1,'Staff']]],
  ['student_5fcount',['student_count',['../class_student.html#acd03ee4535a182c3b9a36f4f8b9e8d31',1,'Student']]],
  ['students',['students',['../class_college.html#a812be176e949a2b67128ebdc5080b32a',1,'College']]],
  ['subjects',['subjects',['../class_student.html#a5956604bcfc594b74c58ddb44927b026',1,'Student::subjects()'],['../class_teacher.html#ab501749adcf43c290ba9422b9a3b0ecd',1,'Teacher::subjects()']]]
];
