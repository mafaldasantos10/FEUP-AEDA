var searchData=
[
  ['teacher_5fcount',['teacher_count',['../class_teacher.html#a571806aabeb146493580e04e35fb7d10',1,'Teacher']]],
  ['thetime',['theTime',['../main_8cpp.html#acb6ffa8d6f93c1ff341894a6822edc99',1,'main.cpp']]]
];
