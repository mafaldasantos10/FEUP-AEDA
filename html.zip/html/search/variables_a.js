var searchData=
[
  ['teacher_5fcount',['teacher_count',['../class_teacher.html#a571806aabeb146493580e04e35fb7d10',1,'Teacher']]],
  ['teachers',['teachers',['../class_college.html#af0c7dc5ec057ce87c19ed29bc0de6dbd',1,'College']]]
];
