var searchData=
[
  ['salary',['salary',['../class_employee.html#a0ad15a19af8e442ceeb212ca9fbc2d50',1,'Employee']]],
  ['staff',['staff',['../class_college.html#a07b018bd8f52f8ea5e835d5aaf993cc9',1,'College']]],
  ['staff_5fcount',['staff_count',['../class_staff.html#a1a2f038a039b1866c757315de15cceba',1,'Staff']]],
  ['staff_5ftable',['staff_table',['../class_employee_ptr.html#a3c5b08daad66cc9123d053a67b983ed1',1,'EmployeePtr']]],
  ['student_5fcount',['student_count',['../class_student.html#acd03ee4535a182c3b9a36f4f8b9e8d31',1,'Student']]],
  ['student_5fptr',['student_ptr',['../class_student___ptr.html#a4fd0934fa34a986de78aa44cc72b7e34',1,'Student_Ptr']]],
  ['students_5fqueue',['students_queue',['../class_college.html#a1aab308af44892bafae0d69aabde2b63',1,'College']]],
  ['studentstree',['studentsTree',['../class_college.html#adc4227fe3719d44a7617f771af5d6bc0',1,'College']]],
  ['subjects',['subjects',['../class_student.html#a5956604bcfc594b74c58ddb44927b026',1,'Student::subjects()'],['../class_teacher.html#ab501749adcf43c290ba9422b9a3b0ecd',1,'Teacher::subjects()']]]
];
