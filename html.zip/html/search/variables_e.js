var searchData=
[
  ['ucects',['ucECTS',['../class_uc.html#a17c903339f45845c300885d93ebb9cf2',1,'Uc']]],
  ['ucname',['ucName',['../class_uc.html#ad66a93e522661d5b423177bd4204ae97',1,'Uc']]],
  ['ucstudent',['ucStudent',['../class_uc.html#a419680d6225d7b872382318136a2e2cf',1,'Uc']]],
  ['ucteacher',['ucTeacher',['../class_uc.html#aebef02ec904dbba15514a3e939663ed4',1,'Uc']]],
  ['ucworkload',['ucWorkload',['../class_uc.html#a33d749f5e126e59a731c33b440cf4d21',1,'Uc']]],
  ['ucyear',['ucYear',['../class_uc.html#a46ebf0756460b0d02bd6f13df902497f',1,'Uc']]],
  ['user_5fid',['user_id',['../main_8cpp.html#a28cda6532ca41bacbadb57a0a18df214',1,'main.cpp']]]
];
